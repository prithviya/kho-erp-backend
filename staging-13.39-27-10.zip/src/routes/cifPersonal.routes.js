const express = require("express");

const router = express.Router();

const controller = require("../controllers/cifPersonal.controller");
const authMiddleware = require("../middleware/auth.middleware");
const { requireAnyRole } = require("../middleware/roleAccess.middleware");

router.use(authMiddleware, requireAnyRole(["hr"]));

router.post("/", controller.create);

router.get("/", controller.getAll);

router.get("/:id", controller.getById);

router.put("/:id", controller.update);

router.delete("/:id", controller.delete);

module.exports = router;