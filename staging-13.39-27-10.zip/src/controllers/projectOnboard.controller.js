const projectOnboardService = require("../services/projectOnboard.service");
const ApiResponse = require("../helpers/apiResponse");
const asyncHandler = require("../helpers/asyncHandler");

exports.createProjectOnboard = asyncHandler(async (req, res) => {
    const { projectName, companyName, serviceIds, projectManagerIds } = req.body;

    if (!projectName || !String(projectName).trim()) {
        return ApiResponse.error(res, "Project name is required.", null, 400);
    }
    if (!companyName || !String(companyName).trim()) {
        return ApiResponse.error(res, "Company name is required.", null, 400);
    }
    if (!Array.isArray(serviceIds) || serviceIds.length === 0) {
        return ApiResponse.error(res, "At least one service is required.", null, 400);
    }
    if (!Array.isArray(projectManagerIds) || projectManagerIds.length === 0) {
        return ApiResponse.error(res, "Reporting Head is required.", null, 400);
    }

    const created = await projectOnboardService.createProjectOnboard(req.body, req.user?.id);
    return ApiResponse.created(res, "Project onboarded successfully.", created);
});

exports.getProjectOnboards = asyncHandler(async (req, res) => {
    const projects = await projectOnboardService.listProjectOnboards(req.user);
    return ApiResponse.success(res, "Projects fetched successfully.", projects);
});

exports.getProjectOnboardById = asyncHandler(async (req, res) => {
    const project = await projectOnboardService.getProjectOnboardById(req.params.id);
    return ApiResponse.success(res, "Project fetched successfully.", project);
});

exports.deleteProjectOnboard = asyncHandler(async (req, res) => {
    await projectOnboardService.deleteProjectOnboard(req.params.id);
    return ApiResponse.success(res, "Project deleted successfully.");
});

exports.updateProjectOnboard = asyncHandler(async (req, res) => {
    const { projectName, companyName, serviceIds, projectManagerIds } = req.body;

    if (!projectName || !String(projectName).trim()) {
        return ApiResponse.error(res, "Project name is required.", null, 400);
    }
    if (!companyName || !String(companyName).trim()) {
        return ApiResponse.error(res, "Company name is required.", null, 400);
    }
    if (!Array.isArray(serviceIds) || serviceIds.length === 0) {
        return ApiResponse.error(res, "At least one service is required.", null, 400);
    }
    if (!Array.isArray(projectManagerIds) || projectManagerIds.length === 0) {
        return ApiResponse.error(res, "Reporting Head is required.", null, 400);
    }

    const updated = await projectOnboardService.updateProjectOnboard(req.params.id, req.body);
    return ApiResponse.success(res, "Project updated successfully.", updated);
});

exports.assignProjectOnboard = asyncHandler(async (req, res) => {
    const { assignedToIds = [], assignedVendorIds = [] } = req.body;

    if ((!Array.isArray(assignedToIds) || assignedToIds.length === 0) && (!Array.isArray(assignedVendorIds) || assignedVendorIds.length === 0)) {
        return ApiResponse.error(res, "At least one employee or vendor is required.", null, 400);
    }
    const updated = await projectOnboardService.assignProjectOnboard(req.params.id, req.body, req.user?.id);
    return ApiResponse.success(res, "Project assigned successfully.", updated);
});
