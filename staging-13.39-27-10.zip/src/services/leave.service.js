const { Op } = require("sequelize");
const db = require("../model");

const APPROVER_ROLES = new Set(["hr", "manager", "superadmin"]);
const CONFLICTING_LEAVE_CODES = new Set([
    "CASUAL_LEAVE",
    "LEAVE_WITHOUT_PAY",
    "PERMISSION",
]);

function normalizeRole(value = "") {
    return String(value)
        .trim()
        .toLowerCase()
        .replace(/[\s_-]+/g, "");
}

function isApprover(user = {}) {
    if (user?.isSuperAdmin) {
        return true;
    }

    const roleSet = user?.roleSet;
    if (!roleSet || typeof roleSet.has !== "function") {
        return false;
    }

    return [...APPROVER_ROLES].some((role) => roleSet.has(normalizeRole(role)));
}

function toNumber(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
}

function toIsoDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
        return null;
    }

    return date.toISOString().slice(0, 10);
}

function getTodayIsoDate() {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${today.getFullYear()}-${month}-${day}`;
}

function inclusiveDiffDays(fromDate, toDate) {
    const from = new Date(fromDate);
    const to = new Date(toDate);
    const diff = Math.floor((to - from) / (24 * 60 * 60 * 1000));
    return diff >= 0 ? diff + 1 : 0;
}

function timeToMinutes(value) {
    const [hh, mm] = String(value || "").split(":").map(Number);
    if (!Number.isInteger(hh) || !Number.isInteger(mm)) {
        return null;
    }

    return hh * 60 + mm;
}

function getYearRange(year) {
    return [`${year}-01-01`, `${year}-12-31`];
}

function getMonthDateRange(year, month) {
    const monthValue = String(month).padStart(2, "0");
    const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
    return [`${year}-${monthValue}-01`, `${year}-${monthValue}-${String(lastDay).padStart(2, "0")}`];
}

function getMonthKeys(fromDate, toDate) {
    const keys = [];
    let year = Number(String(fromDate).slice(0, 4));
    let month = Number(String(fromDate).slice(5, 7));
    const endYear = Number(String(toDate).slice(0, 4));
    const endMonth = Number(String(toDate).slice(5, 7));

    while (year < endYear || (year === endYear && month <= endMonth)) {
        keys.push({ year, month });
        month += 1;
        if (month === 13) {
            month = 1;
            year += 1;
        }
    }

    return keys;
}

function validateCategoryDuration(category, durationType) {
    const allowedDurations = {
        CASUAL_LEAVE: ["FULL_DAY", "HALF_DAY"],
        ON_THE_DUTY: ["FULL_DAY", "HALF_DAY", "QUARTER_DAY", "HOURS"],
        LEAVE_WITHOUT_PAY: ["FULL_DAY", "HALF_DAY", "HOURS"],
        PERMISSION: ["HOURS"],
    }[category.code];

    if (allowedDurations && !allowedDurations.includes(durationType)) {
        throw new Error(`${category.name} does not support ${durationType.replace("_", " ").toLowerCase()}.`);
    }
}

class LeaveService {
    async resolveDesignatedApprover(requester) {
        if (!requester?.employeeRecord) {
            return null;
        }

        const onboardingInfo = await db.OnboardingInfo.findOne({
            where: { employeeId: requester.employeeRecord },
            attributes: ["reportHead"],
            order: [["onboardinginfoid", "DESC"]],
        });
        const configuredHead = String(onboardingInfo?.reportHead || "").trim();
        if (!configuredHead) {
            return null;
        }

        if (/^\d+$/.test(configuredHead)) {
            const byId = await db.User.findOne({
                where: { id: Number(configuredHead), isActive: true },
            });
            if (byId && Number(byId.id) !== Number(requester.id)) {
                return byId;
            }
        }

        const users = await db.User.findAll({
            where: { isActive: true },
            attributes: ["id", "firstName", "lastName", "email", "employeeRecord"],
        });
        const normalizedHead = configuredHead.toLowerCase().replace(/\s+/g, " ");
        return users.find((user) => {
            if (Number(user.id) === Number(requester.id)) return false;
            const displayName = `${user.firstName || ""} ${user.lastName || ""}`.trim().toLowerCase();
            return [user.email, user.employeeRecord, displayName]
                .filter(Boolean)
                .some((value) => String(value).trim().toLowerCase() === normalizedHead);
        }) || null;
    }

    getRequestAccessWhere(filters = {}, actor = {}) {
        const actorId = Number(actor.id);
        if (isApprover(actor) && !filters.userId) {
            const where = {};
            if (filters.status) {
                where.status = String(filters.status).toUpperCase();
            }
            if (filters.year) {
                const year = Number(filters.year);
                if (Number.isInteger(year) && year > 2000) {
                    where.fromDate = {
                        [Op.between]: [`${year}-01-01`, `${year}-12-31`],
                    };
                }
            }
            return where;
        }

        const where = {
            [Op.or]: [
                { userId: actorId },
                { designatedApproverId: actorId },
            ],
        };

        if (filters.userId) {
            where[Op.or] = [{ userId: Number(filters.userId) }];
            if (Number(filters.userId) === actorId) {
                where[Op.or].push({ designatedApproverId: actorId });
            }
        }

        if (filters.status) {
            where.status = String(filters.status).toUpperCase();
        }

        if (filters.year) {
            const year = Number(filters.year);
            if (Number.isInteger(year) && year > 2000) {
                where.fromDate = {
                    [Op.between]: [`${year}-01-01`, `${year}-12-31`],
                };
            }
        }

        return where;
    }

    async ensureConflictingLeaveOverlap({ userId, category, fromDate, toDate, excludeRequestId = null }) {
        if (!CONFLICTING_LEAVE_CODES.has(category.code)) {
            return;
        }

        const where = {
            userId,
            fromDate: { [Op.lte]: toDate },
            toDate: { [Op.gte]: fromDate },
            status: { [Op.in]: ["PENDING", "APPROVED"] },
        };

        if (excludeRequestId) {
            where.id = { [Op.ne]: excludeRequestId };
        }

        const existingRequests = await db.LeaveRequest.findAll({
            where,
            include: [{
                model: db.LeaveCategory,
                as: "category",
                attributes: ["code", "name"],
            }],
        });

        const conflictingCodes = {
            CASUAL_LEAVE: ["LEAVE_WITHOUT_PAY", "PERMISSION"],
            LEAVE_WITHOUT_PAY: ["CASUAL_LEAVE", "PERMISSION"],
            PERMISSION: ["CASUAL_LEAVE", "LEAVE_WITHOUT_PAY"],
        };
        const conflictingRequest = existingRequests.find((request) =>
            conflictingCodes[category.code]?.includes(request.category?.code)
        );

        if (conflictingRequest) {
            const error = new Error(
                `${conflictingRequest.category.name} is already booked for an overlapping date.`
            );
            error.status = 400;
            throw error;
        }
    }

    async ensureCasualLeaveMonthsAvailable({ userId, categoryId, fromDate, toDate, requestedDays, excludeRequestId = null }) {
        const monthKeys = getMonthKeys(fromDate, toDate);

        if (toNumber(requestedDays) > monthKeys.length) {
            const error = new Error("Casual Leave is limited to 1 day per calendar month.");
            error.status = 400;
            throw error;
        }

        for (const { year, month } of monthKeys) {
            const [monthStart, monthEnd] = getMonthDateRange(year, month);
            const where = {
                userId,
                categoryId,
                fromDate: { [Op.lte]: monthEnd },
                toDate: { [Op.gte]: monthStart },
                status: { [Op.in]: ["PENDING", "APPROVED"] },
            };

            if (excludeRequestId) {
                where.id = { [Op.ne]: excludeRequestId };
            }

            const existingRequest = await db.LeaveRequest.findOne({ where });
            if (existingRequest) {
                const error = new Error(`Casual Leave is already booked for ${year}-${String(month).padStart(2, "0")}.`);
                error.status = 400;
                throw error;
            }
        }
    }

    async getCategoryBookingStats({ userId, categoryId, year, throughDate = null, excludeRequestId = null }) {
        const [fromYearDate, toYearDate] = getYearRange(year);
        const where = {
            userId,
            categoryId,
            fromDate: { [Op.between]: [fromYearDate, throughDate || toYearDate] },
            status: { [Op.in]: ["PENDING", "APPROVED"] },
        };

        if (excludeRequestId) {
            where.id = { [Op.ne]: excludeRequestId };
        }

        const requests = await db.LeaveRequest.findAll({ where });
        return requests.reduce(
            (acc, request) => {
                acc.days += toNumber(request.requestedDays);
                acc.hours += toNumber(request.requestedHours);
                return acc;
            },
            { days: 0, hours: 0 }
        );
    }

    async ensureBalanceAvailable({ category, userId, fromDate, toDate, requestedDays, requestedHours, excludeRequestId = null }) {
        if (["LEAVE_WITHOUT_PAY", "ON_THE_DUTY"].includes(category.code)) {
            return;
        }

        const year = Number(String(fromDate).slice(0, 4)) || new Date().getFullYear();
        let allocated = toNumber(category.allocatedValue);

        if (category.code === "CASUAL_LEAVE") {
            await this.ensureCasualLeaveMonthsAvailable({
                userId,
                categoryId: category.id,
                fromDate,
                toDate: toDate || fromDate,
                requestedDays,
                excludeRequestId,
            });
            return;
        } else if (category.code === "PERMISSION") {
            const fromDateObj = new Date(fromDate);
            const month = fromDateObj.getMonth();
            const fromMonthDate = new Date(year, month, 1).toISOString().slice(0, 10);
            // using last day of month
            const toMonthDate = new Date(year, month + 1, 0).toISOString().slice(0, 10);
            
            const where = {
                userId,
                categoryId: category.id,
                fromDate: { [Op.between]: [fromMonthDate, toMonthDate] },
                status: { [Op.in]: ["PENDING", "APPROVED"] },
            };
            if (excludeRequestId) {
                where.id = { [Op.ne]: excludeRequestId };
            }
            
            const monthRequests = await db.LeaveRequest.findAll({ where });
            const monthBookedHours = monthRequests.reduce((acc, req) => acc + toNumber(req.requestedHours), 0);
            const incoming = toNumber(requestedHours);
            
            if (monthBookedHours + incoming > 2) {
                const error = new Error(`Permission exceeds 2 hours per month. Available ${Number((2 - monthBookedHours).toFixed(2))} hours.`);
                error.status = 400;
                throw error;
            }
            return;
        }

        const stats = await this.getCategoryBookingStats({
            userId,
            categoryId: category.id,
            year,
            throughDate:
                category.code === "CASUAL_LEAVE"
                    ? `${year}-${String(Number(String(fromDate).slice(5, 7))).padStart(2, "0")}-${new Date(year, Number(String(fromDate).slice(5, 7)), 0).getDate()}`
                    : null,
            excludeRequestId,
        });

        const alreadyBooked = category.unit === "HOUR" ? stats.hours : stats.days;
        const incoming = category.unit === "HOUR" ? toNumber(requestedHours) : toNumber(requestedDays);
        const remaining = Number((allocated - alreadyBooked).toFixed(2));

        if (incoming > remaining) {
            const unitLabel = category.unit === "HOUR" ? "hours" : "days";
            const error = new Error(
                `Insufficient leave balance. Available ${remaining.toFixed(2)} ${unitLabel}, requested ${incoming.toFixed(2)} ${unitLabel}.`
            );
            error.status = 400;
            throw error;
        }
    }

    async getCategories() {
        return db.LeaveCategory.findAll({
            where: { isActive: true },
            order: [["id", "ASC"]],
        });
    }

    async createCategory(payload = {}) {
        const code = String(payload.code || "")
            .trim()
            .toUpperCase();

        if (!code) {
            throw new Error("Leave category code is required.");
        }

        const existing = await db.LeaveCategory.findOne({ where: { code } });
        if (existing) {
            throw new Error("Leave category code already exists.");
        }

        return db.LeaveCategory.create({
            code,
            name: String(payload.name || code).trim(),
            unit: String(payload.unit || "DAY").toUpperCase() === "HOUR" ? "HOUR" : "DAY",
            allocatedValue: toNumber(payload.allocatedValue),
            isActive: payload.isActive !== false,
        });
    }

    async updateCategory(id, payload = {}) {
        const category = await db.LeaveCategory.findByPk(id);
        if (!category) {
            return null;
        }

        const nextCode = payload.code
            ? String(payload.code).trim().toUpperCase()
            : category.code;

        if (nextCode !== category.code) {
            const existing = await db.LeaveCategory.findOne({ where: { code: nextCode } });
            if (existing) {
                throw new Error("Leave category code already exists.");
            }
        }

        await category.update({
            code: nextCode,
            name: payload.name !== undefined ? String(payload.name || "").trim() : category.name,
            unit:
                payload.unit !== undefined
                    ? String(payload.unit).toUpperCase() === "HOUR"
                        ? "HOUR"
                        : "DAY"
                    : category.unit,
            allocatedValue:
                payload.allocatedValue !== undefined
                    ? toNumber(payload.allocatedValue)
                    : category.allocatedValue,
            isActive: payload.isActive !== undefined ? Boolean(payload.isActive) : category.isActive,
        });

        return category;
    }

    getRequestWhere(filters = {}, actor = {}) {
        const where = {};

        if (!isApprover(actor)) {
            where.userId = actor.id;
        } else if (filters.userId) {
            where.userId = Number(filters.userId);
        }

        if (filters.status) {
            where.status = String(filters.status).toUpperCase();
        }

        if (filters.year) {
            const year = Number(filters.year);
            if (Number.isInteger(year) && year > 2000) {
                where.fromDate = {
                    [Op.between]: [`${year}-01-01`, `${year}-12-31`],
                };
            }
        }

        return where;
    }

    async listRequests(filters = {}, actor = {}) {
        return db.LeaveRequest.findAll({
            where: this.getRequestAccessWhere(filters, actor),
            include: [
                {
                    model: db.LeaveCategory,
                    as: "category",
                    attributes: ["id", "code", "name", "unit", "allocatedValue"],
                },
                {
                    model: db.User,
                    as: "designatedApprover",
                    attributes: ["id", "firstName", "lastName", "email"],
                },
            ],
            order: [["createdAt", "DESC"]],
        });
    }

    async listCalendarRequests(year, month) {
        const calendarYear = Number(year);
        const calendarMonth = Number(month);
        if (
            !Number.isInteger(calendarYear)
            || calendarYear < 1900
            || calendarYear > 9999
            || !Number.isInteger(calendarMonth)
            || calendarMonth < 1
            || calendarMonth > 12
        ) {
            const error = new Error("A valid calendar year and month are required.");
            error.status = 400;
            throw error;
        }

        const monthStart = `${calendarYear}-${String(calendarMonth).padStart(2, "0")}-01`;
        const monthEnd = `${calendarYear}-${String(calendarMonth).padStart(2, "0")}-${String(
            new Date(Date.UTC(calendarYear, calendarMonth, 0)).getUTCDate()
        ).padStart(2, "0")}`;

        const requests = await db.LeaveRequest.findAll({
            where: {
                fromDate: { [Op.lte]: monthEnd },
                toDate: { [Op.gte]: monthStart },
                status: { [Op.in]: ["PENDING", "APPROVED"] },
            },
            attributes: [
                "id",
                "employeeName",
                "clientName",
                "fromDate",
                "toDate",
                "durationType",
                "session",
                "quarterSlot",
                "status",
            ],
            include: [
                {
                    model: db.LeaveCategory,
                    as: "category",
                    attributes: ["code", "name"],
                },
                {
                    model: db.User,
                    as: "requester",
                    attributes: ["firstName", "lastName"],
                },
            ],
            order: [["fromDate", "ASC"], ["createdAt", "ASC"]],
        });

        return requests.map((request) => {
            const data = request.toJSON();
            const requesterName = [data.requester?.firstName, data.requester?.lastName]
                .filter(Boolean)
                .join(" ")
                .trim();

            return {
                id: data.id,
                employeeName: data.employeeName || requesterName || "Employee",
                categoryName: data.category?.name || "Leave",
                categoryCode: data.category?.code || null,
                clientName: data.category?.code === "ON_THE_DUTY" ? data.clientName : null,
                fromDate: data.fromDate,
                toDate: data.toDate,
                durationType: data.durationType,
                session: data.session,
                quarterSlot: data.quarterSlot,
                status: data.status,
            };
        });
    }

    async getRequestById(id, actor = {}) {
        const request = await db.LeaveRequest.findByPk(id, {
            include: [
                {
                    model: db.LeaveCategory,
                    as: "category",
                    attributes: ["id", "code", "name", "unit", "allocatedValue"],
                },
                {
                    model: db.User,
                    as: "designatedApprover",
                    attributes: ["id", "firstName", "lastName", "email"],
                },
            ],
        });

        if (!request) {
            return null;
        }

        if (
            Number(request.userId) !== Number(actor.id) &&
            Number(request.designatedApproverId) !== Number(actor.id) &&
            !isApprover(actor)
        ) {
            const error = new Error("You can only view your own leave requests.");
            error.status = 403;
            throw error;
        }

        return request;
    }

    async computeAmount(category, payload = {}) {
        const fromDate = toIsoDate(payload.fromDate);
        const toDate = toIsoDate(payload.toDate || payload.fromDate);

        if (!fromDate || !toDate) {
            throw new Error("Valid fromDate and toDate are required.");
        }

        if (toDate < fromDate) {
            throw new Error("toDate must be greater than or equal to fromDate.");
        }

        const durationType = String(payload.durationType || "FULL_DAY").toUpperCase();
        validateCategoryDuration(category, durationType);

        let requestedDays = 0;
        let requestedHours = 0;

        if (category.unit === "HOUR") {
            if (durationType === "HOURS") {
                const start = timeToMinutes(payload.startTime);
                const end = timeToMinutes(payload.endTime);
                if (start === null || end === null || end <= start) {
                    throw new Error("Valid startTime and endTime are required for hour based leave.");
                }
                requestedHours = Number(((end - start) / 60).toFixed(2));
            } else {
                requestedHours = toNumber(payload.requestedHours);
            }

            if (requestedHours <= 0) {
                throw new Error("Requested permission hours must be greater than zero.");
            }
        } else {
            if (durationType === "HALF_DAY") {
                requestedDays = 0.5;
            } else if (durationType === "QUARTER_DAY") {
                requestedDays = 0.25;
            } else {
                requestedDays = inclusiveDiffDays(fromDate, toDate);
            }

            if (requestedDays <= 0) {
                throw new Error("Requested leave days must be greater than zero.");
            }
        }

        return {
            fromDate,
            toDate,
            durationType,
            requestedDays,
            requestedHours,
        };
    }

    async applyLeaveRules(category, userId, calculated, excludeRequestId = null) {
        let finalCategory = category;
        let adjustedCalculated = { ...calculated };

        if (finalCategory.code === "PERMISSION") {
            const year = Number(String(adjustedCalculated.fromDate).slice(0, 4));
            const month = new Date(adjustedCalculated.fromDate).getMonth();
            const fromMonthDate = new Date(year, month, 1).toISOString().slice(0, 10);
            const toMonthDate = new Date(year, month + 1, 0).toISOString().slice(0, 10);
            
            const where = {
                userId,
                categoryId: finalCategory.id,
                fromDate: { [Op.between]: [fromMonthDate, toMonthDate] },
                status: { [Op.in]: ["PENDING", "APPROVED"] },
            };
            if (excludeRequestId) {
                where.id = { [Op.ne]: excludeRequestId };
            }
            const monthRequests = await db.LeaveRequest.findAll({ where });
            const monthBookedHours = monthRequests.reduce((acc, req) => acc + toNumber(req.requestedHours), 0);
            
            if (monthBookedHours + adjustedCalculated.requestedHours > 2) {
                const clCategory = await db.LeaveCategory.findOne({ where: { code: "CASUAL_LEAVE" } });
                if (clCategory) {
                    finalCategory = clCategory;
                    adjustedCalculated.durationType = "HALF_DAY";
                    adjustedCalculated.requestedDays = 0.5;
                    adjustedCalculated.requestedHours = 0;
                }
            }
        }

        if (finalCategory.code === "CASUAL_LEAVE") {
            const today = new Date(`${getTodayIsoDate()}T00:00:00`);
            const fromDateObj = new Date(`${adjustedCalculated.fromDate}T00:00:00`);
            const diffInDays = Math.floor((fromDateObj - today) / (1000 * 60 * 60 * 24));
            
            if (diffInDays < 2) {
                const lopCategory = await db.LeaveCategory.findOne({ where: { code: "LEAVE_WITHOUT_PAY" } });
                if (lopCategory) {
                    finalCategory = lopCategory;
                }
            }
        }

        await this.ensureConflictingLeaveOverlap({
            userId,
            category: finalCategory,
            fromDate: adjustedCalculated.fromDate,
            toDate: adjustedCalculated.toDate,
            excludeRequestId,
        });

        await this.ensureBalanceAvailable({
            category: finalCategory,
            userId,
            fromDate: adjustedCalculated.fromDate,
            toDate: adjustedCalculated.toDate,
            requestedDays: adjustedCalculated.requestedDays,
            requestedHours: adjustedCalculated.requestedHours,
            excludeRequestId
        });

        return { finalCategory, adjustedCalculated };
    }

    async createRequest(payload = {}, actor = {}) {
        const categoryId = Number(payload.categoryId);
        if (!categoryId) {
            throw new Error("categoryId is required.");
        }

        const category = await db.LeaveCategory.findByPk(categoryId);
        if (!category || !category.isActive) {
            throw new Error("Leave category not found.");
        }

        const clientName = String(payload.clientName || "").trim();
        if (category.code === "ON_THE_DUTY" && !clientName) {
            const error = new Error("Client name is required for On The Duty leave.");
            error.status = 400;
            throw error;
        }

        const requesterId = isApprover(actor) && payload.userId
            ? Number(payload.userId)
            : Number(actor.id);

        if (!requesterId) {
            throw new Error("Requester is required.");
        }

        const requester = await db.User.findByPk(requesterId);
        if (!requester) {
            throw new Error("Requester user not found.");
        }

        const designatedApprover = await this.resolveDesignatedApprover(requester);

        const calculated = await this.computeAmount(category, payload);

        const { finalCategory, adjustedCalculated } = await this.applyLeaveRules(
            category,
            requesterId,
            calculated
        );

        return db.LeaveRequest.create({
            userId: requesterId,
            employeeCode: requester.employeeRecord || null,
            employeeName: `${requester.firstName || ""} ${requester.lastName || ""}`.trim() || requester.email,
            clientName: finalCategory.code === "ON_THE_DUTY" ? clientName : null,
            categoryId: finalCategory.id,
            fromDate: adjustedCalculated.fromDate,
            toDate: adjustedCalculated.toDate,
            durationType: adjustedCalculated.durationType,
            session: payload.session ? String(payload.session).toUpperCase() : null,
            quarterSlot: payload.quarterSlot ? Number(payload.quarterSlot) : null,
            startTime: payload.startTime || null,
            endTime: payload.endTime || null,
            requestedDays: adjustedCalculated.requestedDays,
            requestedHours: adjustedCalculated.requestedHours,
            reason: payload.reason || null,
            status: "PENDING",
            designatedApproverId: designatedApprover?.id || null,
        });
    }

    async updateRequest(id, payload = {}, actor = {}) {
        const request = await db.LeaveRequest.findByPk(id, {
            include: [{ model: db.LeaveCategory, as: "category" }],
        });

        if (!request) {
            return null;
        }

        const approver = isApprover(actor);
        const owner = Number(request.userId) === Number(actor.id);
        if (!approver && !owner) {
            const error = new Error("You can only edit your own leave request.");
            error.status = 403;
            throw error;
        }

        if (!approver && request.status !== "PENDING") {
            const error = new Error("Only pending requests can be edited.");
            error.status = 400;
            throw error;
        }

        const categoryId = payload.categoryId ? Number(payload.categoryId) : request.categoryId;
        const category = categoryId === request.categoryId
            ? request.category
            : await db.LeaveCategory.findByPk(categoryId);

        if (!category || !category.isActive) {
            throw new Error("Leave category not found.");
        }

        const clientName = payload.clientName === undefined
            ? String(request.clientName || "").trim()
            : String(payload.clientName || "").trim();
        if (category.code === "ON_THE_DUTY" && !clientName) {
            const error = new Error("Client name is required for On The Duty leave.");
            error.status = 400;
            throw error;
        }

        const calculated = await this.computeAmount(category, {
            fromDate: payload.fromDate || request.fromDate,
            toDate: payload.toDate || request.toDate,
            durationType: payload.durationType || request.durationType,
            startTime: payload.startTime || request.startTime,
            endTime: payload.endTime || request.endTime,
            requestedHours: payload.requestedHours,
        });

        const { finalCategory, adjustedCalculated } = await this.applyLeaveRules(
            category,
            request.userId,
            calculated,
            request.id
        );

        await request.update({
            categoryId: finalCategory.id,
            fromDate: adjustedCalculated.fromDate,
            toDate: adjustedCalculated.toDate,
            durationType: adjustedCalculated.durationType,
            session: payload.session ? String(payload.session).toUpperCase() : request.session,
            quarterSlot:
                payload.quarterSlot !== undefined
                    ? Number(payload.quarterSlot || 0) || null
                    : request.quarterSlot,
            startTime: payload.startTime !== undefined ? payload.startTime : request.startTime,
            endTime: payload.endTime !== undefined ? payload.endTime : request.endTime,
            requestedDays: adjustedCalculated.requestedDays,
            requestedHours: adjustedCalculated.requestedHours,
            clientName: finalCategory.code === "ON_THE_DUTY" ? clientName : null,
            reason: payload.reason !== undefined ? payload.reason : request.reason,
        });

        return request;
    }

    async deleteRequest(id, actor = {}) {
        const request = await db.LeaveRequest.findByPk(id);
        if (!request) {
            return false;
        }

        const approver = isApprover(actor);
        const owner = Number(request.userId) === Number(actor.id);
        if (!approver && !owner) {
            const error = new Error("You can only delete your own leave request.");
            error.status = 403;
            throw error;
        }

        if (!approver && request.status !== "PENDING") {
            const error = new Error("Only pending requests can be deleted.");
            error.status = 400;
            throw error;
        }

        await request.destroy();
        return true;
    }

    async updateRequestStatus(id, payload = {}, actor = {}) {
        const request = await db.LeaveRequest.findByPk(id);
        if (!request) {
            return null;
        }

        if (Number(request.designatedApproverId) !== Number(actor.id)) {
            const error = new Error("Only the employee's designated reporting approver can approve or reject this leave request.");
            error.status = 403;
            throw error;
        }

        const status = String(payload.status || "")
            .trim()
            .toUpperCase();

        if (!["APPROVED", "REJECTED"].includes(status)) {
            const error = new Error("Status must be APPROVED or REJECTED.");
            error.status = 400;
            throw error;
        }

        const approverRemarks = String(payload.approverRemarks || "").trim();
        if (status === "REJECTED" && !approverRemarks) {
            const error = new Error("Approver remarks are required when rejecting a leave request.");
            error.status = 400;
            throw error;
        }

        await request.update({
            status,
            approverId: actor.id,
            approverRemarks: approverRemarks || null,
            approvedAt: new Date(),
        });

        return request;
    }

    async getSummary(actor = {}, query = {}) {
        const year = Number(query.year) || new Date().getFullYear();
        const targetUserId = isApprover(actor) && query.userId
            ? Number(query.userId)
            : Number(actor.id);

        if (!targetUserId) {
            throw new Error("User context is required.");
        }

        const [categories, requests] = await Promise.all([
            this.getCategories(),
            db.LeaveRequest.findAll({
                where: {
                    userId: targetUserId,
                    fromDate: {
                        [Op.between]: [`${year}-01-01`, `${year}-12-31`],
                    },
                    status: {
                        [Op.in]: ["PENDING", "APPROVED"],
                    },
                },
            }),
        ]);

        const byCategory = new Map();
        categories.forEach((category) => {
            let allocated = toNumber(category.allocatedValue);
            
            if (category.code === "CASUAL_LEAVE") {
                const currentYear = new Date().getFullYear();
                if (year === currentYear) {
                    allocated = Math.max(0, 12 - new Date().getMonth());
                } else if (year < currentYear) {
                    allocated = 12;
                } else {
                    allocated = 0;
                }
            } else if (category.code === "PERMISSION") {
                const currentYear = new Date().getFullYear();
                if (year < currentYear) {
                    allocated = 24;
                } else if (year === currentYear) {
                    allocated = Math.max(0, 12 - new Date().getMonth()) * 2;
                } else {
                    allocated = 0;
                }
            } else if (["LEAVE_WITHOUT_PAY", "ON_THE_DUTY"].includes(category.code)) {
                allocated = 0;
            }

            byCategory.set(category.id, {
                categoryId: category.id,
                code: category.code,
                name: category.name,
                unit: category.unit,
                unlimited: ["LEAVE_WITHOUT_PAY", "ON_THE_DUTY"].includes(category.code),
                allocated,
                booked: 0,
                taken: 0,
                pending: 0,
                available: allocated,
            });
        });

        requests.forEach((request) => {
            const entry = byCategory.get(request.categoryId);
            if (!entry) return;

            if (
                entry.code === "CASUAL_LEAVE" &&
                year === new Date().getFullYear() &&
                Number(String(request.fromDate).slice(5, 7)) < new Date().getMonth() + 1
            ) {
                return;
            }

            const amount = entry.unit === "HOUR"
                ? toNumber(request.requestedHours)
                : toNumber(request.requestedDays);

            entry.booked += amount;
            if (request.status === "APPROVED") {
                entry.taken += amount;
            }
            if (request.status === "PENDING") {
                entry.pending += amount;
            }
            if (!entry.unlimited) {
                entry.available = Number((entry.allocated - entry.booked).toFixed(2));
            }
        });

        const list = [...byCategory.values()];
        const totals = list.reduce(
            (acc, item) => {
                if (item.unit === "HOUR") {
                    acc.totalBookedHours += item.booked;
                    acc.totalTakenHours += item.taken;
                } else {
                    acc.totalBookedDays += item.booked;
                    acc.totalTakenDays += item.taken;
                }
                return acc;
            },
            {
                totalBookedDays: 0,
                totalBookedHours: 0,
                totalTakenDays: 0,
                totalTakenHours: 0,
            }
        );

        return {
            userId: targetUserId,
            year,
            categories: list.map((item) => ({
                ...item,
                booked: Number(item.booked.toFixed(2)),
                taken: Number(item.taken.toFixed(2)),
                pending: Number(item.pending.toFixed(2)),
                available: Number(item.available.toFixed(2)),
            })),
            totals: {
                totalBookedDays: Number(totals.totalBookedDays.toFixed(2)),
                totalBookedHours: Number(totals.totalBookedHours.toFixed(2)),
                totalTakenDays: Number(totals.totalTakenDays.toFixed(2)),
                totalTakenHours: Number(totals.totalTakenHours.toFixed(2)),
            },
        };
    }

    isApproverUser(user = {}) {
        return isApprover(user);
    }
}

module.exports = new LeaveService();
