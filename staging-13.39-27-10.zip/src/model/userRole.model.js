module.exports = (sequelize, DataTypes) => {
    return sequelize.define(
        "UserRole",
        {
            userId: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true
            },
            roleId: {
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true
            },
        },
        {
            tableName: "user_roles",
            timestamps: false,
        }
    );
};